1. Python must be pre-installed in your computer.
2. Run the setup.cmd file to install the required libraries.
3. Extract the sharever folder in C: 
if you want to extract any other location 