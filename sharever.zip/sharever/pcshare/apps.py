from django.apps import AppConfig


class PcshareConfig(AppConfig):
    name = 'pcshare'
